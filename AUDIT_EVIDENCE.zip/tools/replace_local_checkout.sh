#!/usr/bin/env bash
# Optional, explicit local replacement. Does not push to GitHub or delete the user's backups.
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="${1:-}"
if [[ -z "$TARGET" || ! -d "$TARGET/.git" ]]; then echo 'Usage: bash tools/replace_local_checkout.sh /path/to/alfred-university-git-checkout'; exit 2; fi
if [[ "$(cd "$TARGET" && pwd)" == "$HERE" ]]; then echo 'Cannot replace the currently unpacked release itself.'; exit 2; fi
REMOTE="$(git -C "$TARGET" remote get-url origin 2>/dev/null || true)"
if [[ "$REMOTE" != *numberclaw2/alfred-university* ]]; then echo "Checkout origin doesn't match the expected Alfred repository: $REMOTE"; exit 2; fi
if ! git -C "$TARGET" diff --quiet || ! git -C "$TARGET" diff --cached --quiet; then echo 'Please commit or stash existing working-tree changes first.'; exit 2; fi
BACKUP="${TARGET%/}-pre-ceta-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
(cd "$TARGET" && tar --exclude=.git -cf - .) | (cd "$BACKUP" && tar -xf -)
echo "Local backup created at $BACKUP"
find "$TARGET" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf -- {} +
(cd "$HERE" && tar --exclude='./tools/replace_local_checkout.sh' -cf - .) | (cd "$TARGET" && tar -xf -)
git -C "$TARGET" add -A
printf '\nStaged local changes (nothing published):\n'
git -C "$TARGET" status --short | head -70
printf '\nReview this diff; only you can commit and push it.\n'
