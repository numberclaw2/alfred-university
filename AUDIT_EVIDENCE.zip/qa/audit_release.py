#!/usr/bin/env python3
"""Static, reproducible audit of the installed CETa-only course. Uses stdlib only."""
from pathlib import Path
import json,collections,re,hashlib,sys,subprocess
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'data/course.json').read_text())
mods=data['course'];results=[]
def check(name,condition,detail=''):
 results.append({'test':name,'status':'PASS' if condition else 'FAIL','detail':detail})
 return condition
html=list(root.glob('*.html'))
check('Exactly 30 learning modules',len(mods)==30,f'{len(mods)} modules')
check('Canonical module IDs',[m['id'] for m in mods]==[f'M{i:02}' for i in range(1,31)])
all_obj=[(m['id'],o['id']) for m in mods for o in m['objectives']]
check('262 unique objectives',len(all_obj)==262 and len(set(y for x,y in all_obj))==262,f'{len(all_obj)} listed')
check('84 section registry entries',sum(len(m['sections']) for m in mods)==84)
check('All modules contain teaching pages',all(len(m['pages'])>=7 for m in mods),str([(m['id'],len(m['pages'])) for m in mods]))
check('Every page carries source provenance',all(x.get('sourceWeek') and x.get('sourceLesson') for m in mods for x in m['pages']))
check('Teaching pages have prose',all(len(x['text'])>55 for m in mods for x in m['pages']))
check('All modules have sourced practice',all(len(m['questions'])>=4 for m in mods))
check('Exam rehearsal has 100 questions',len(mods[28]['questions'])==100)
check('No accidental duplicate question IDs within a module',all(len({q['id'] for q in m['questions']})==len(m['questions']) for m in mods))
check('No dummy study-guide PDF bundled',not (root/'Associate_CET_Study_Guide_Sixth_Edition.pdf').exists())
check('Official guide mapping retains 62 records',len(data.get('studyGuideIndex',[]))==62)
check('All required reading records link to 30 modules',all(x.get('chapter') and x.get('pages') for m in mods for x in m['readings']))
check('Legacy original file intentionally not bundled',not (root/'curriculum-data.js').exists())
check('Old Career-specific code not loaded',not any('career-' in p.name for p in root.glob('*.js')))
check('Primary pages',len(html)==26 and all((root/(x+'.html')).exists() for x in ['index','learn','study','practice','labs','assessments','progress','analytics','standards','resources','glossary','calendar','search','course','documents','about']))
check('Common script and style files',all((root/x).exists() for x in ['ceta.js','ceta.css','service-worker.js','data/course.js','manifest.webmanifest','icon-192.png','alfred-university-crest.png']))
check('Static data and generated JS match', (root/'data/course.js').read_text().strip()=='window.ALFRED_CETA_DATA='+(root/'data/course.json').read_text().strip()+';')
check('HTML pages are not blank',all('<h1>' in (root/(x+'.html')).read_text() or '<div id="app"' in (root/(x+'.html')).read_text() for x in ['index','learn','study','practice','labs','progress','standards','resources','glossary','calendar','search','course','documents','about']))
check('HTML dependencies resolved',all((root/p).exists() for p in ['ceta.css','ceta.js','data/course.js','alfred-university-crest.png','icon-192.png']))
jsfiles=[root/'ceta.js',root/'service-worker.js',root/'data/course.js'];syntax=[]
for path in jsfiles:
 r=subprocess.run(['node','--check',str(path)],capture_output=True,text=True);syntax.append((path.name,r.returncode,r.stderr[:200]))
check('JavaScript syntax verified',all(x[1]==0 for x in syntax),str(syntax))
sw=(root/'service-worker.js').read_text();a=sw.split('const STATIC=')[1].split(';')[0];
try: paths=json.loads(a.replace("'",'"'));broken=[p for p in paths if not (root/p).exists() and p!='./']
except Exception as e:broken=['service worker manifest cannot be read: '+str(e)]
check('Offline pre-cache list resolved',not broken,str(broken))
# Distinguish structural success from instructional verification, required licensing and backend tests.
blocked=[{'id':'EDU-01','status':'NOT_VERIFIED','description':'Independent subject-matter review of all 262 objective teaching and coverage claims'},
{'id':'EDU-02','status':'NOT_VERIFIED','description':'External publisher current specifications and all official study-guide page/errata reconciliation'},
{'id':'ASSESS-01','status':'NOT_VERIFIED','description':'Expansion and psychometric review of uneven 180-question eligible base bank'},
{'id':'MEDIA-01','status':'NOT_VERIFIED','description':'Working availability and licensing of external teaching-media links'},
{'id':'SYNC-01','status':'NOT_VERIFIED','description':'Live Cloud Sync remote merge across devices and data-loss regression'},
{'id':'GUIDE-01','status':'NOT_VERIFIED','description':'Private guide IndexedDB PDF persistence under production GitHub origin'},
{'id':'OFFLINE-01','status':'NOT_VERIFIED','description':'Service worker installation and offline navigation at production URL'},
{'id':'A11Y-01','status':'NOT_VERIFIED','description':'Full WCAG 2.2 AA accessibility audit with assistive technology'}]
manifest={'course':'Alfred University CETa-only remodel','version':'1.0.1','tests':results,'passed':sum(r['status']=='PASS' for r in results),'failed':sum(r['status']=='FAIL' for r in results),'blocked':blocked,'counts':{'modules':len(mods),'instructionalPages':sum(len(m['pages']) for m in mods),'sections':sum(len(m['sections']) for m in mods),'objectives':len(all_obj),'guideIndexRecords':len(data['studyGuideIndex']),'sourceLabsAssigned':sum(len(m['labs']) for m in mods),'browserPages':len(html)},'artifacts':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'ceta.js',root/'ceta.css',root/'data/course.json',root/'service-worker.js']}}
(root/'audit'/'STATIC_AUDIT.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'passed':manifest['passed'],'failed':manifest['failed'],'blocked':len(blocked),'counts':manifest['counts'],'failures':[x for x in results if x['status']=='FAIL']},indent=2))
sys.exit(1 if manifest['failed'] else 0)
