# Release notes — CETa-only remodel v1.0.1

Source repository captured: `numberclaw2/alfred-university`, Git commit `c0e831d22ec7d1c345f8a3629d145d483844635f` (October 2026 baseline).

- Replaced legacy seven-stage CETa/Career Classroom with a five-stage CETa-only learning sequence.
- Consolidated previous multi-script runtime into one application runtime, one stylesheet, and one canonical course data registry.
- Created 30 modules, 84 section targets, 373 instructor-content-derived teaching pages, 262 provisional ETA objective maps, and 23 CETa-relevant application routes.
- Retired mandatory Career lessons, resume/portfolio/interview milestones, and outdated dual-track pages; provided redirects for their legacy URLs.
- Integrated official study-guide printed-page assignments and errata references; added on-device private PDF connection rather than shipping the guide publicly.
- Added per-page reading progress, question feedback, graded module checks, independent mock evidence, self-paced planning, study reviews, and careful legacy state isolation.
- Added common responsive shell, simplified navigation, export/import, optional Cloud Sync reconciliation, and PWA caching.
- Added structured QA/audit bundle and reproducible checks.

### Known limitations

The content migration is a structural and first-pass educational remodel, not a completed expert review of every concept. Original CETa base questions cover 111 of 262 provisional objective entries at the editorially reviewed level. Full exam-bank breadth, current online media availability, remote synchronization and real-device assistive-technology checks remain to be verified. Independent ETA exam performance and actual physical workmanship cannot be inferred from this site.
