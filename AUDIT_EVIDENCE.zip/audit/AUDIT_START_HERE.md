# START HERE — Alfred CETa-only v1.0.1

Current site architecture is intentionally small. Its authoritative instructional data is `data/course.json`; `data/course.js` is a generated equivalent consumed by static pages. `ceta.js` is the single application runtime; `ceta.css` is the single stylesheet; `service-worker.js` is the one PWA cache service. All 26 HTML routes either render a meaningful screen or redirect to its CETa equivalent.

## Where to look

1. `audit/STATIC_AUDIT.json` — machine-generated structural checks and explicit release blockers.
2. `audit/OBJECTIVE_EVIDENCE.csv` — each of the 262 mapped objectives, primary proposed module/section, sourced base question IDs, and verification status.
3. `audit/TEACHING_PAGE_SOURCES.csv` — every migrated teaching page, original week/lesson/track, target module, and proposed section.
4. `audit/STUDY_GUIDE_INDEX.csv` — all 62 official guide mapping records, chapter and original printed page group.
5. `audit/source-mappings/` — frozen Phase 14 draft registries, including 24 lab dispositions and the original objective/section registry.
6. `qa/audit_release.py` — repeatable, dependency-free static tests.
7. `audit/BROWSER_QA.json` — recorded browser smoke-test coverage and limitations.

## Important verification status

The 262 rows in the registry are a **planning alignment**, not proof that every standard has sufficiently deep instruction or eligible graded questions. The active imported base bank had 180 editorially reviewed CETa questions covering 111 of the 262 IDs before any additional runtime augmentation. Current course scores are aggregate, not individual skill certification. The 100-question internal practice set draws on that uneven bank.

The provided publisher PDF scan was reviewed for page indexing, but the entire book was not independently analyzed or republished. The public ZIP excludes it. Official publisher current corrections take precedence. Use the private local connector and metadata.

## Regression loop for the next iteration

Run `python3 qa/audit_release.py`; use browser smoke tests on all 30 module routes and 16 primary pages; verify incorrect-answer → teaching → back-to-question; test save/export/import and legacy record isolation; test Cloud Sync using nonproduction records; verify publisher resources; audit keyboard/mobile/assistive-technology behavior. A future source revision must update `data/course.json` first and regenerate the `course.js` wrapper.
